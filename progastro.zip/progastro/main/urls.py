from django.urls import path
from . import views


urlpatterns = [
    path('', views.index),
    path('about', views.about),
    path('koloproktologiya', views.koloproktologiya),
    path('endoskopia', views.endoskopia),
    path('gastroenterologiya', views.gastroenterologiya),
    path('lab-issledovaniya', views.lab_issledovaniya),
    path('uzi', views.uzi),
    path('docs', views.docs),

    path('blog', views.blog),
    path('price-list', views.pricelist),
    path('callback', views.callback, name = 'backcall'),

    path('oferta', views.oferta),
    path('success', views.success, name = 'success')
]