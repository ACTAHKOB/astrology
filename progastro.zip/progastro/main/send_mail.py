import smtplib

def send_mail(message):
    from_email = 'mishko651@gmail.com'
    password = 'lrezqjueznnekvtl'
    
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()

    try:
        server.login(from_email, password)
        server.sendmail(from_email, 'support@progastro.ru', message)
        
        return "completed"
    except Exception as _ex:
        print(_ex)
        return f"{_ex}\n\nThere is a problem"