from django.db import models
from django.db import connection


class Blog(models.Model):
    name = models.CharField(max_length=250)
    description = models.TextField(max_length=500)
    date_create = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
class PriceList(models.Model):
    usluga = models.CharField(max_length=100)
    price = models.IntegerField()
    