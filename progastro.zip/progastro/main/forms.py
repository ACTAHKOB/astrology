from django import forms
from .models import *

class CallbackForm(forms.Form):
    name = forms.CharField(max_length=255, label='Имя')
    number = forms.CharField(max_length=20, label="Телефон")