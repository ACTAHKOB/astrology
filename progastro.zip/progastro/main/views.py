from django.shortcuts import render, redirect
from .models import Blog, PriceList
from .forms import *
#from django.core.mail import EmailMessage, EmailMultiAlternatives
from django.template.loader import render_to_string
#from .send_mail import send_mail
from email.message import EmailMessage
import smtplib
#from django.core.mail import se
#from .models import Blog, PriceList
# Create your views here.
def index(request):
    
    #send_mail('to e testovoe soobschenie')
    return render(request, 'main/index.html')

def about(request):
    return render(request, 'main/about.html')

def koloproktologiya(request):
    return render(request, 'main/koloproktologiya.html')

def endoskopia(request):
    return render(request, 'main/endoskopia.html')

def gastroenterologiya(request):
    return render(request, 'main/gastroenterologiya.html')

def lab_issledovaniya(request):
    return render(request, 'main/lab-issledovaniya.html')

def uzi(request):
    return render(request, 'main/uzi.html')

def docs(request):
    return render(request, 'main/docs.html')


def blog(request):

    articles = Blog.objects.all()
    data = {'articles':list(articles)}

    return render(request, 'main/blog.html', data)


def pricelist(request):

    prices = PriceList.objects.all()
    data = {'prices':list(prices)}

    return render(request, 'main/price-list.html', data)

def callback(request):
    

    return render(request, 'main/callback.html')

def success(request):
    from_email = 'mishko651@gmail.com'
    password = 'lrezqjueznnekvtl'
    
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()

    server.login(from_email, password)
    
    #send_mail(message)
    name = str(request.GET['name'])
    phone = str(request.GET['phone'])    
    
    msg = EmailMessage()
    msg.set_content(f'Обратный звонок\n\nИмя клиента: {name}\nТелефон клиента: {phone}')
    msg['To'] = 'support@progastro.ru'
    msg['From'] = from_email
    msg['Subject'] = 'Обратный звонок | progastro.ru'

    server.send_message(msg)

    server.quit()

        
    return render(request, 'main/success_page.html')

def oferta(request):
    return render(request, 'main/oferta.html')
